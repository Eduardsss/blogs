<?php

return [
  "host" => "localhost",
  "dbname" => "blog_eduards",
  "user" => "root",
  "password" => "",
  "charset" => "utf8mb4"
];
