<?php 
require "components/head.php";
require "components/navbar.php";
?>
    <p> :(  </p>
<?php
require "components/footer.php";  
?>
