
<?php 
require "views/components/head.php";
require "views/components/navbar.php";
?>
    <h1> Edit a Post </h1>
    <form method="POST">
        <label>Title
            <input name="title" value="<?= $_POST["title"] ?? "" ?>"/>
            <?php if (isset($errors["title"])) { ?>
                <p class="invalid-data"> <?= $errors["title"] ?> </p>
            <?php } ?>
        </label>
        <label>Category_ID
            <select name="cat_id">
                <option value="1" <?$post["cat_id"] == 1 ? "selected" : "" ?>>sport</option>
                <option value="2" <?$post["cat_id"] == 2 ? "selected" : "" ?>>music</option>
                <option value="3" <?$post["cat_id"] == 3 ? "selected" : "" ?>>food</option>
            </select> 
    <?php if (isset($errors["cat_id"])) { ?>
        <p class="invalid-data"> <?= $errors["cat_id"] ?> </p>
    <?php } ?>
        </label>
        <button>Submit</button>
    </form>
<?php
require "views/components/footer.php";  
?>