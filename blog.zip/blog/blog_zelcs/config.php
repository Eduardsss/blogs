<?php

return [
    "host" => "localhost",
    "dbname" => "blog_zelcs",
    "user" => "root",
    "password" => "",
    "charset" => "utf8mb4"
];