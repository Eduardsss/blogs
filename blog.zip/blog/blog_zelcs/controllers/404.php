<?php
$title = "404 Sold the world";
require "views/404.view.php";