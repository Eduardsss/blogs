<?php 
require "components/head.php";
require "components/navbar.php";
?>
<h1> 404 Page not found! </h1>
<h2> Muļķis! Lapas nav! </h2>
<?php 
require "components/footer.php";
?>