<?php
$title = "That is NOT Solid Snake!";
require "views/about.view.php";