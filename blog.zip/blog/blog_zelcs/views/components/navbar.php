<header>
        <nav>
            <a href="./"> Posts </a>        
            <a href="./about"> About us </a>
            <a href="./story"> Story </a>
            <a href="./create"> Create </a>
            <a href="./delete"> Delete </a>
        </nav>
</header>