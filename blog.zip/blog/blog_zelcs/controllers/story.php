<?php

// Ieraksti bloga vietnes nosaukumu!
$title = "DraugiemLV";
$programmers = ["Jānis Mārtiņš", "Oskars", "Emīls", "Edmunds", "Oskars", "Adrians", "Ralfs", "Railijs Didzis", "Kristers", "Roberts Aldis", "Gustavs", "Kristaps Imants", "Elvis", "Adrians", "Matīss Mareks", "Markus", "Kristers", "Marsels", "Kristaps Toms", "Eduards", "Jēkabs", "Big Boss"] ;
require "./views/story.view.php";